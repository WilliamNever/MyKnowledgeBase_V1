﻿using System;

namespace XunitExtensions
{
    [AttributeUsage(AttributeTargets.Method)]
    public class ObservationAttribute : Attribute { }
}
