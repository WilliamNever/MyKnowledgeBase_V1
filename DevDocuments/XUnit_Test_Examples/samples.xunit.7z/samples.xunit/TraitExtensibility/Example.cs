using System.Threading;
using Xunit;

public class Example
{
    [Fact, Category("Trait")]
    public void ExampleFact()
    {
        Assert.True(true); 
    }
}