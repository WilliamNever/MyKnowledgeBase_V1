(function ($) {
    'use strict';
    const modalLayerDefaults = {
        title: '',
        content: '',
        closeOnBackdropClick: true,
        closeOnEsc: true,
        showCloseButton: true,
        width: '560px',
        maxWidth: '90vw',
        cssClass: '',
        onOpen: null,
        onClose: null
    }

    var openModalCount = 0

    function ModalLayer(options) {
        this.options = $.extend({}, modalLayerDefaults, options)
        this.instanceId = 'jquery-modal-layer-' + new Date().getTime() + '-' + Math.floor(Math.random() * 1000)
        this.titleId = this.instanceId + '-title'
        this.isOpen = false
        this.lastFocusedElement = null
        this.$overlay = null
        this.$dialog = null
        this.$title = null
        this.$body = null
        this.$closeButton = null

        this.Build()
        this.ApplyOptions()
        this.SetTitle(this.options.title)
        this.SetContent(this.options.content)
        this.BindEvents()
    }

    ModalLayer.prototype.Build = function () {
        var html = ''
            + '<div class="jquery-modal-layer" aria-hidden="true">'
            + '    <div class="jquery-modal-layer__dialog" role="dialog" aria-modal="true" tabindex="-1">'
            + '        <div class="jquery-modal-layer__header">'
            + '            <h2 class="jquery-modal-layer__title"></h2>'
            + '            <button type="button" class="jquery-modal-layer__close" aria-label="Close">&times;</button>'
            + '        </div>'
            + '        <div class="jquery-modal-layer__body"></div>'
            + '    </div>'
            + '</div>'

        this.$overlay = $(html)
        this.$dialog = this.$overlay.find('.jquery-modal-layer__dialog')
        this.$title = this.$overlay.find('.jquery-modal-layer__title')
        this.$body = this.$overlay.find('.jquery-modal-layer__body')
        this.$closeButton = this.$overlay.find('.jquery-modal-layer__close')

        this.$dialog.attr('aria-labelledby', this.titleId)
        this.$title.attr('id', this.titleId)

        $('body').append(this.$overlay)
    }

    ModalLayer.prototype.BindEvents = function () {
        var self = this

        this.$overlay.on('click', function (event) {
            if (!self.options.closeOnBackdropClick) {
                return
            }

            if (event.target === self.$overlay[0]) {
                self.Close()
            }
        })

        this.$closeButton.on('click', function () {
            self.Close()
        })

        $(document).on('keydown.' + this.instanceId, function (event) {
            if (!self.isOpen) {
                return
            }

            if (event.key === 'Escape' && self.options.closeOnEsc) {
                event.preventDefault()
                self.Close()
            }
        })
    }

    ModalLayer.prototype.ApplyOptions = function () {
        this.$dialog.css({
            width: this.options.width,
            maxWidth: this.options.maxWidth
        })

        this.$closeButton.toggle(this.options.showCloseButton)

        this.$dialog.removeClass(function (index, className) {
            return (className.match(/(^|\s)modal-layer-custom-\S+/g) || []).join(' ')
        })

        if (this.options.cssClass) {
            this.$dialog.addClass(this.options.cssClass)
        }
    }

    ModalLayer.prototype.SetTitle = function (title) {
        this.$title.html(title || '')
    }

    ModalLayer.prototype.SetContent = function (content) {
        this.$body.empty()

        if (!content) {
            return
        }

        if (content.jquery) {
            this.$body.append(content)
            return
        }

        if (content.nodeType) {
            this.$body.append($(content))
            return
        }

        this.$body.html(content)
    }

    ModalLayer.prototype.UpdateOptions = function (options) {
        this.options = $.extend({}, this.options, options)
        this.ApplyOptions()

        if (Object.prototype.hasOwnProperty.call(options, 'title')) {
            this.SetTitle(options.title)
        }

        if (Object.prototype.hasOwnProperty.call(options, 'content')) {
            this.SetContent(options.content)
        }
    }

    ModalLayer.prototype.Open = function (options) {
        if (options) {
            this.UpdateOptions(options)
        }

        if (this.isOpen) {
            this.$dialog.trigger('focus')
            return
        }

        this.lastFocusedElement = document.activeElement
        this.isOpen = true
        openModalCount += 1

        $('body').addClass('jquery-modal-layer-open')
        this.$overlay.addClass('is-open').attr('aria-hidden', 'false')
        this.$dialog.trigger('focus')

        if (typeof this.options.onOpen === 'function') {
            this.options.onOpen(this)
        }
    }

    ModalLayer.prototype.Close = function () {
        if (!this.isOpen) {
            return
        }

        this.isOpen = false
        openModalCount = Math.max(0, openModalCount - 1)

        this.$overlay.removeClass('is-open').attr('aria-hidden', 'true')

        if (openModalCount === 0) {
            $('body').removeClass('jquery-modal-layer-open')
        }

        if (this.lastFocusedElement && typeof this.lastFocusedElement.focus === 'function') {
            this.lastFocusedElement.focus()
        }

        if (typeof this.options.onClose === 'function') {
            this.options.onClose(this)
        }
    }

    ModalLayer.prototype.Destroy = function () {
        this.Close()
        $(document).off('keydown.' + this.instanceId)
        this.$overlay.remove()
    }

    $.modalLayer = function (options) {
        return new ModalLayer(options)
    }
})(jQuery)

/*

Usages -

    <link rel="stylesheet" href="~/css/jquery-modal-layer.css" asp-append-version="true" />
    <script src="~/js/jquery-modal-layer.js" asp-append-version="true"></script>

var keepOpenModal = $.modalLayer({
    title: 'Locked modal',
    content: '<p>This modal does not close on background click or Esc.</p>',
    closeOnBackdropClick: false,
    closeOnEsc: false
})

var autoCloseModal = $.modalLayer({
    title: 'Auto close modal',
    content: '<p>This modal closes on background click or Esc.</p>',
    closeOnBackdropClick: true,
    closeOnEsc: true
})

$('#btnKeepOpen').on('click', function () {
    keepOpenModal.Open()
})

$('#btnAutoClose').on('click', function () {
    autoCloseModal.Open()
})
*/