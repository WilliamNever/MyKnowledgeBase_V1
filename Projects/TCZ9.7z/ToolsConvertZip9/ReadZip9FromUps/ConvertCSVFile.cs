﻿using LumenWorks.Framework.IO.Csv;
using ReadZip9FromUps.ParamModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ReadZip9FromUps
{
    public delegate void CallBackMessage(SearchStatus status, string message);
    public class ConvertCSVFile
    {
        private string OriCssPath;
        private string DestinCssPath;

        private bool IsIncludeHeaderLine;

        private FileStream fsOri, fsDes, logFile;
        private StreamReader sr;
        private StreamWriter sw,logSw;

        public ConvertCSVFile(string oriCssPth, string destinCssPath, bool isIncludeHeaderLine)
        {
            OriCssPath = oriCssPth;
            DestinCssPath = destinCssPath;
            IsIncludeHeaderLine = isIncludeHeaderLine;
        }

        private void Open()
        {
            fsOri = File.Open(OriCssPath, FileMode.OpenOrCreate);
            sr = new StreamReader(fsOri);

            fsDes = new FileStream(DestinCssPath, FileMode.Create);
            sw = new StreamWriter(fsDes);

            logFile = new FileStream(DestinCssPath + ".log", FileMode.Create);
            logSw = new StreamWriter(logFile);
        }
        private void Close()
        {
            sw.Flush();
            sw.Close();
            fsDes.Close();

            sr.Close();
            fsOri.Close();

            logSw.Flush();
            logSw.Close();
            logFile.Close();
        }

        public void GoWork()
        {
            GoWork(null, null);
        }
        public void GoWork(Form form, CallBackMessage callBack)
        {
            if (form != null && callBack != null)
            {
                form.Invoke(callBack, null, "begin to convert");
            }

            Open();

            using (var csv = new CsvReader(sr, false))
            {
                int RowIndex = 1;
                string ZipCode;
                SearchStatus result = null;

                if (IsIncludeHeaderLine && csv.ReadNextRecord())
                {
                    WriteHeaderLine(csv);
                    RowIndex++;
                }
                
                while (csv.ReadNextRecord())
                {
                    result = new ParamModel.SearchStatus();
                    ZipCode = csv[11];
                    if (string.IsNullOrWhiteSpace(ZipCode) || ZipCode.Length < 9)
                    {
                        result.RowIndex = RowIndex;
                        result.Zip5Code = ZipCode;
                        result = GetSearchResponse(csv, result);
                    }

                    WriteCSVLine(csv, result);
                    WriteLogLine(result);

                    if (form != null && callBack != null)
                    {
                        form.Invoke(callBack, result, "");
                    }

                    RowIndex++;
                }
            }

            Close();

            if (form != null && callBack != null)
            {
                form.Invoke(callBack, null, "finish the search");
            }
        }

        private void WriteLogLine(SearchStatus result)
        {
            if (result != null)
            {
                if (result.UpdateStatu== UpdateStatus.MultipleZip4 
                    || result.UpdateStatu== UpdateStatus.AddressError
                    || result.UpdateStatu== UpdateStatus.NoResults
                    )
                {
                    logSw.WriteLine($"Line {result.RowIndex}:{result.UpdateStatu.ToString()}");
                    logSw.WriteLine($"Request:");
                    logSw.WriteLine($"{result.RequestJson}");
                    logSw.WriteLine($"Response:");
                    logSw.WriteLine($"{result.ResponseJson}");
                    logSw.WriteLine();
                }
            }
        }

        private void WriteCSVLine(CsvReader csv, SearchStatus result)
        {
            //11 - C_ZIP_CD
            for (int i = 0; i < 11; i++)
            {
                sw.Write($"{csv[i]},");
            }

            if (result.UpdateStatu == UpdateStatus.UpdatedWithZip4
                || result.UpdateStatu == UpdateStatus.MultipleZip4)
            {
                sw.Write($"{result.Zip9Code},");
            }
            else
            {
                sw.Write($"{csv[11]},");
            }

            for (int i = 12; i < csv.FieldCount; i++)
            {
                sw.Write($"{csv[i]},");
            }

            if (result.UpdateStatu != UpdateStatus.IsZip9)
            {
                sw.Write($"{result.UpdateStatu.ToString()}");
            }
            sw.WriteLine();
        }

        private SearchStatus GetSearchResponse(CsvReader csv, SearchStatus result)
        {
            #region Cloumn Index Indicated
            /*
             * 6 - C_ADDR
             * 7 - C_ADDR2
             * 8 - C_CITY
             * 10 - C_STATE
             * 11 - C_ZIP_CD
             * 12 - COUNTRY_DESC
             */
            //if (!string.IsNullOrWhiteSpace(csv[7]))
            //{
            //    sAddr.AddressLine.Add(csv[7]);
            //}
            #endregion

            AddressKeyFormatClass sAddr = new AddressKeyFormatClass();

            if (!string.IsNullOrWhiteSpace(csv[6]))
            {
                sAddr.AddressLine.Add(csv[6]);
            }
            else
            {
                sAddr.AddressLine.Add(csv[7]);
            }
            
            sAddr.PoliticalDivision2 = csv[8];
            sAddr.PoliticalDivision1 = csv[10];
            sAddr.PostcodePrimaryLow = result.Zip5Code;
            sAddr.CountryCode = !string.IsNullOrWhiteSpace(csv[12]) && csv[12].Length > 2 ? csv[12].Substring(0, 2) : csv[12];

            result.RequestJson = ReadZip9FromUPS.GetInputJson(sAddr);
            result.ResponseJson = ReadZip9FromUPS.GetSearchRequest(result.RequestJson);

            return result;
        }

        private void WriteHeaderLine(CsvReader csv)
        {
            for (int i = 0; i < csv.FieldCount; i++)
            {
                sw.Write(csv[i]);
                sw.Write(",");
            }
            sw.WriteLine();
            sw.Flush();
        }
    }
}
