﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReadZip9FromUps.ParamModel
{
    public class SearchAddr {
        public UPSSecurityClass UPSSecurity { get; set; }

        
        public XAVRequestClass XAVRequest { get; set; }

        public SearchAddr()
        {
            UPSSecurity = new UPSSecurityClass();
            XAVRequest = new XAVRequestClass();
            
        }
    }
    public class UPSSecurityClass
    {
        public UsernameTokenClass UsernameToken { get; set; }
        public ServiceAccessTokenClass ServiceAccessToken { get; set; }
        public UPSSecurityClass()
        {
            UsernameToken = new ParamModel.UsernameTokenClass();
            ServiceAccessToken = new ParamModel.ServiceAccessTokenClass();
        }
    }
    public class UsernameTokenClass
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    public class ServiceAccessTokenClass
    {
        public string AccessLicenseNumber { get; set; }
    }

    public class XAVRequestClass
    {
        public RequestClass Request { get; set; }
        public string MaximumListSize { get; set; }
        public AddressKeyFormatClass AddressKeyFormat { get; set; }

        public XAVRequestClass()
        {
            Request = new RequestClass();
            MaximumListSize = "10";
        }

    } 
    public class AddressKeyFormatClass
    {
        public List<string> AddressLine { get; set; }
        public string PoliticalDivision2 { get; set; }
        public string PoliticalDivision1 { get; set; }
        public string PostcodePrimaryLow { get; set; }
        public string CountryCode { get; set; }

        public AddressKeyFormatClass()
        {
            AddressLine = new List<string>();
        }
    }

    public class RequestClass
    {
        public List<string> RequestOption { get; set; }
        public RequestClass()
        {
            RequestOption = new List<string>();
            RequestOption.Add("1");
        }
    }
}
