﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace ReadZip9FromUps.ParamModel
{
    public class SearchStatus
    {
        public int RowIndex { get; set; }
        public UpdateStatus UpdateStatu { get; set; }
        public string Zip9Code { get; set; }
        public string Zip5Code { get; set; }
        public string RequestJson { get; set; }
        public string ResponseJson
        {
            get
            {
                return _ResponseJson;
            }
            set
            {
                _ResponseJson = value;
                CalculateResult();
            }
        }

        private void CalculateResult()
        {
            var zip5Matchers = zip5Pattern.Matches(ResponseJson);
            var zip4Matchers = zip4Pattern.Matches(ResponseJson);
            if (SuccessStatusPattern.IsMatch(ResponseJson))
            {
                if (zip5Matchers.Count > 0)
                {
                    Zip9Code = zip5Matchers[0].Value.Replace("\"", "").Split(':')[1].Trim()
                        + zip4Matchers[0].Value.Replace("\"", "").Split(':')[1].Trim();
                    UpdateStatu = UpdateStatus.MultipleZip4;
                    if (zip5Matchers.Count == 1)
                    {
                        UpdateStatu = UpdateStatus.UpdatedWithZip4;
                    }
                }
                else
                {
                    UpdateStatu = UpdateStatus.NoResults;
                }
            }
            else
            {
                UpdateStatu = UpdateStatus.AddressError;
            }
        }

        private string _ResponseJson;
        private Regex zip5Pattern;
        private Regex zip4Pattern;
        private Regex SuccessStatusPattern;
        public SearchStatus()
        {
            zip5Pattern = new Regex("\"PostcodePrimaryLow\"[ ]*:[ ]*\"[0-9]{5}\"", RegexOptions.IgnoreCase);
            zip4Pattern = new Regex("\"PostcodeExtendedLow\"[ ]*:[ ]*\"[0-9]{4}\"", RegexOptions.IgnoreCase);
            SuccessStatusPattern = new Regex("\"Description\"[ ]*:[ ]*\"Success\"", RegexOptions.IgnoreCase);

            UpdateStatu = UpdateStatus.IsZip9;
        }
    }

    public enum UpdateStatus
    {
        AddressError = -1,
        NoResults = 0,
        UpdatedWithZip4 = 1,
        MultipleZip4 = 2,
        IsZip9 = 9
    }
}
