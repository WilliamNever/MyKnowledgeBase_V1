﻿  <appSettings>
    <add key="upsUserId" value="*******"/>
    <add key="upsPassword" value="*******"/>
    <add key="upsAccessLicenseNumber" value="*******"/>
    <add key="upsServiceUrl" value="https://wwwcie.ups.com/rest/XAV"/>
    <add key="PoliticalDivision1" value="CA"/>
    <add key="ToSetPolicicalDivision1AsPreSet" value="yes"/>
  </appSettings>

In the config file, adding the appSetting as stated above.

Configurations:
upsUserId is the UPS Username.

upsPassword is the UPS Password.

upsAccessLicenseNumber is the UPS AccessLicenseNumber.

upsServiceUrl is the UPS json service.

PoliticalDivision1 is the PoliticalDivision1 in the request Json.

ToSetPolicicalDivision1AsPreSet defines whether to use the PoliticalDivision1 that is preseted in the config file or the value in the data row.
yes: to use the preset value in the config file.
no: to use the value in the data row.
PS: I have tested if the value is set to no. There are lots of data row not to convert to zip+4.

Usages:
1. Double click the ToolsConvertZip9.exe file can run in the window form.
2. The Program can be run in the console without the form also. 
Command line is: ToolsConvertZip9 SourceFilePath ExportFilePath. 
Example: ToolsConvertZip9 c:\\Manju.csv c:\\Export.csv

Thank you!
Hope it is useful to you!