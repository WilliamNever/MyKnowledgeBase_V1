﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using ReadZip9FromUps.ParamModel;
using System.IO;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Web.Script.Serialization;

namespace ReadZip9FromUps
{
    public class ReadZip9FromUPS
    {
        private static Encoding CodeEncoding = Encoding.UTF8;
        private static string upsUserId { get; set; }
        private static string upsPassword { get; set; }
        private static string upsAccessLicenseNumber { get; set; }
        private static string upsServiceUrl { get; set; }
        private static string PoliticalDivision1 { get; set; }
        private static string ToSetPolicicalDivision1AsPreSet { get; set; }

        public static string GetSearchRequest(string requestJson)
        {
            string rValue = "";
            HttpWebRequest hwr = WebRequest.Create(upsServiceUrl) as HttpWebRequest;

            if (hwr != null)
            {
                byte[] inputBytes = CodeEncoding.GetBytes(requestJson);
                hwr.Method = "POST";
                hwr.ContentType = "application/json";
                var RequestSteam = hwr.GetRequestStream();
                RequestSteam.Write(inputBytes, 0, inputBytes.Length);
                var responseReader = new StreamReader(hwr.GetResponse().GetResponseStream(), CodeEncoding);
                rValue = responseReader.ReadToEnd();
                RequestSteam.Close();
                responseReader.Close();

            }
            return rValue;
        }

        public static string GetInputJson(AddressKeyFormatClass sAddr)
        {
            string rValue = "";

            #region
            //rValue = "{\"UPSSecurity\":{\"UsernameToken\":{\"Username\":\"******\",\"Password\":\"******\"},\"ServiceAccessToken\":{\"AccessLicenseNumber\":\"******\"}},\"XAVRequest\":{\"Request\":{\"RequestOption\":[\"1\"],\"TransactionReference\":null},\"RegionalRequestIndicator\":null,\"MaximumCandidateListSize\":\"10\",\"AddressKeyFormat\":{\"ConsigneeName\":\"Some Consignee\",\"AttentionName\":null,\"AddressLine\":[\"3930 KRISTI COURT\"],\"PoliticalDivision2\":\"Cumming\",\"PoliticalDivision1\":\"CA\",\"PostcodePrimaryLow\":\"95827\",\"PostcodeExtendedLow\":null,\"Region\":null,\"Urbanization\":\"SACRAMENTO CA 95827\",\"CountryCode\":\"US\"}}}";
            //rValue = "{\"UPSSecurity\":{\"UsernameToken\":{\"Username\":\"******\",\"Password\":\"******\"},\"ServiceAccessToken\":{\"AccessLicenseNumber\":\"******\"}},\"XAVRequest\":{\"Request\":{\"RequestOption\":[\"1\"]},\"MaximumListSize\":\"10\",\"AddressKeyFormat\":{\"AddressLine\":[\"3930 KRISTI COURT\"],\"PoliticalDivision2\":\"Cumming\",\"PoliticalDivision1\":\"CA\",\"PostcodePrimaryLow\":\"95827\",\"CountryCode\":\"US\"}}}";

            //rValue = "{\"UPSSecurity\":{\"UsernameToken\":{\"Username\":\"******\",\"Password\":\"******\"},\"ServiceAccessToken\":{\"AccessLicenseNumber\":\"******\"}},\"XAVRequest\":{\"Request\":{\"RequestOption\":[\"1\"]},\"MaximumCandidateListSize\":\"10\",\"AddressKeyFormat\":{\"AddressLine\":\"1000 S 22ND ST\",\"PoliticalDivision2\":\"ST CLAIR\",\"PoliticalDivision1\":\"IL\",\"PostcodePrimaryLow\":\"\",\"CountryCode\":\"US\"}}}";

            //rValue = "{\"UPSSecurity\":{\"UsernameToken\":{\"Username\":\"******\",\"Password\":\"******\"},\"ServiceAccessToken\":{\"AccessLicenseNumber\":\"******\"}},\"XAVRequest\":{\"Request\":{\"RequestOption\":[\"1\"]},\"MaximumListSize\":\"10\",\"AddressKeyFormat\":{\"AddressLine\":[\"14265 Corrine CT\"],\"PoliticalDivision2\":\"Broomfield\",\"PoliticalDivision1\":\"CA\",\"CountryCode\":\"US\"}}}";
            //rValue = "{\"UPSSecurity\":{\"UsernameToken\":{\"Username\":\"******\",\"Password\":\"******\"},\"ServiceAccessToken\":{\"AccessLicenseNumber\":\"******\"}},\"XAVRequest\":{\"Request\":{\"RequestOption\":[\"1\"]},\"MaximumListSize\":\"10\",\"AddressKeyFormat\":{\"AddressLine\":[\"14265 Corrine CT\"],\"PoliticalDivision2\":\"Broomfield\",\"PoliticalDivision1\":\"CO\",\"PostcodePrimaryLow\":\"80023\",\"CountryCode\":\"US\"}}}";

            //rValue = "{\"UPSSecurity\":{\"UsernameToken\":{\"Username\":\"******\",\"Password\":\"******\"},\"ServiceAccessToken\":{\"AccessLicenseNumber\":\"******\"}},\"XAVRequest\":{\"Request\":{\"RequestOption\":[\"1\"]},\"MaximumListSize\":\"10\",\"AddressKeyFormat\":{\"AddressLine\":[\"8200 Dodge Street\"],\"PoliticalDivision2\":\"Omaha\",\"PoliticalDivision1\":\"CA\",\"CountryCode\":\"US\"}}}";

            //return rValue;
            #endregion

            if (ToSetPolicicalDivision1AsPreSet.ToLower().Equals("yes"))
            {
                sAddr.PoliticalDivision1 = PoliticalDivision1;
            }
            SearchAddr searcher = new ParamModel.SearchAddr();
            searcher.UPSSecurity.UsernameToken.Username = upsUserId;
            searcher.UPSSecurity.UsernameToken.Password = upsPassword;
            searcher.UPSSecurity.ServiceAccessToken.AccessLicenseNumber = upsAccessLicenseNumber;
            searcher.XAVRequest.AddressKeyFormat = sAddr;

            JavaScriptSerializer jss = new JavaScriptSerializer();
            rValue = jss.Serialize(searcher);
            return rValue;
        }

        static ReadZip9FromUPS()
        {
            upsUserId = System.Configuration.ConfigurationManager.AppSettings["upsUserId"];
            upsPassword = System.Configuration.ConfigurationManager.AppSettings["upsPassword"];
            upsAccessLicenseNumber = System.Configuration.ConfigurationManager.AppSettings["upsAccessLicenseNumber"];
            upsServiceUrl = System.Configuration.ConfigurationManager.AppSettings["upsServiceUrl"];
            PoliticalDivision1 = System.Configuration.ConfigurationManager.AppSettings["PoliticalDivision1"];
            ToSetPolicicalDivision1AsPreSet = System.Configuration.ConfigurationManager.AppSettings["ToSetPolicicalDivision1AsPreSet"];

            System.Net.ServicePointManager.SecurityProtocol = System.Net.SecurityProtocolType.Tls12
                | System.Net.SecurityProtocolType.Ssl3
                | System.Net.SecurityProtocolType.Tls
                | System.Net.SecurityProtocolType.Tls11;
        }

        private static void ShowAppSettings()
        {
            Console.WriteLine(upsUserId);
            Console.WriteLine(upsPassword);
            Console.WriteLine(upsAccessLicenseNumber);
            Console.WriteLine(upsServiceUrl);
            Console.WriteLine(PoliticalDivision1);
        }
    }
}
