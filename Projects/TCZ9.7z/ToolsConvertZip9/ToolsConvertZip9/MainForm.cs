﻿using ReadZip9FromUps;
using ReadZip9FromUps.ParamModel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToolsConvertZip9
{
    public partial class MainForm : Form
    {
        private Thread thr = null;
        public MainForm()
        {
            InitializeComponent();
        }

        private void btnOriPath_Click(object sender, EventArgs e)
        {
            OpenFileDialog opf = new OpenFileDialog();
            opf.Filter = "csv|*.csv";
            opf.Multiselect = false;
            opf.FileName = txtOriPath.Text;

            if (opf.ShowDialog() == DialogResult.OK)
            {
                txtOriPath.Text = opf.FileName;
            }
        }

        private void btnExportPath_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "csv|*.csv";
            sfd.OverwritePrompt = false;
            sfd.AddExtension = true;
            sfd.DefaultExt = "csv";
            sfd.FileName = txtExportPath.Text;

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                txtExportPath.Text = sfd.FileName;
            }
        }

        private void btnConvert_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtOriPath.Text)
                && !string.IsNullOrWhiteSpace(txtExportPath.Text))
            {
                if (!System.IO.File.Exists(txtOriPath.Text))
                {
                    txtMessage.Text = "The Source File does not exist. Please verify the file.";
                    txtMessage.Text += "\r\n";
                    return;
                }
                if (txtOriPath.Text.Equals(txtExportPath.Text))
                {
                    txtMessage.Text = "The Source File and the Export File cannot be the same one.";
                    txtMessage.Text += "\r\n";
                    return;
                }

                if (thr != null && thr.ThreadState == ThreadState.Running)
                {
                    MessageBox.Show(this, "Is in processing!");
                }
                else
                {
                    txtMessage.Text = "";
                    thr = new Thread(new ThreadStart(RunConvert));
                    thr.Start();
                }
            }
            else
            {
                txtMessage.Text = "Please input the file path!";
                txtMessage.Text += "\r\n";
            }
        }
        
        public void RunConvert()
        {
            ConvertCSVFile csv = new ConvertCSVFile(txtOriPath.Text, txtExportPath.Text, true);
            csv.GoWork(this, new CallBackMessage(ShowBackMessages));
        }

        public void ShowBackMessages(SearchStatus result, string message)
        {
            if (!string.IsNullOrWhiteSpace(message))
            {
                txtMessage.Text += message;
                txtMessage.Text += "\r\n";
            }
            if (result != null)
            {
                if (result.UpdateStatu == ReadZip9FromUps.ParamModel.UpdateStatus.MultipleZip4
                    || result.UpdateStatu == ReadZip9FromUps.ParamModel.UpdateStatus.AddressError
                    || result.UpdateStatu == ReadZip9FromUps.ParamModel.UpdateStatus.NoResults
                    )
                {
                    txtMessage.Text += $"Line {result.RowIndex}:{result.UpdateStatu.ToString()}\r\n";
                    txtMessage.Text += $"Request:\r\n";
                    txtMessage.Text += $"{result.RequestJson}\r\n";
                    txtMessage.Text += $"Response:\r\n";
                    txtMessage.Text += $"{result.ResponseJson}\r\n";
                    txtMessage.Text += "\r\n";
                }
            }
            txtMessage.Select(txtMessage.TextLength, 0);
            txtMessage.ScrollToCaret();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (thr != null && thr.ThreadState == ThreadState.Running)
            {
                thr.Abort();
            }
        }
    }
}
