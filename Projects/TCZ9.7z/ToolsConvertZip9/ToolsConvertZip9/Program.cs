﻿using ReadZip9FromUps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToolsConvertZip9
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            if (args.Length > 0)
            {
                if (args.Length == 2)
                {
                    if (!System.IO.File.Exists(args[0]))
                    {
                        Console.WriteLine($"The Source File does not exist. Please verify the file.");
                        return;
                    }
                    if (args[0].Equals(args[1]))
                    {
                        Console.WriteLine($"The Source File and the Export File cannot be the same one.");
                        return;
                    }
                    Console.WriteLine("Begin to convert....");
                    ConvertCSVFile csv = new ConvertCSVFile(args[0], args[1], true);
                    csv.GoWork();
                    Console.WriteLine("Finished.....");
                }
                else
                {
                    Console.WriteLine($"The Program can be run in the console without the form.");
                    Console.WriteLine($"Command line is: ToolsConvertZip9 SourceFilePath ExportFilePath");
                    Console.WriteLine($"Example: ToolsConvertZip9 c:\\Manju.csv c:\\Export.csv");
                    Console.WriteLine();
                    Console.WriteLine($"Also it can be run with the form.");
                }
            }
            else
            {
                Console.WriteLine($"The Program can be run in the console without the form.");
                Console.WriteLine($"Command line is: ToolsConvertZip9 SourceFilePath ExportFilePath");
                Console.WriteLine($"Example: ToolsConvertZip9 c:\\Manju.csv c:\\Export.csv");
                Application.Run(new MainForm());
            }
        }
    }
}
